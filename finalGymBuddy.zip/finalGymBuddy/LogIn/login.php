<?php
// Connect to the database
$host = "localhost";
$user = "root";
$password = "";
$dbname = "gymbuddy";
$conn = mysqli_connect($host, $user, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the email and password from the form
    $email = $_POST['Email'];
    $password = $_POST['Password'];

    // Retrieve the user record based on the provided email
    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = mysqli_query($conn, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $storedPassword = $row['password'];

        // Verify the entered password against the stored password
        if ($password === $storedPassword) {
            $name = $row['name'];
            $surname = $row['surname'];
            // Password is correct, redirect to another page
            header("Location: http://localhost/finalGymBuddy/HomePage/homepage.php?name=$name&surname=$surname");
            exit;
        } else {
            // Incorrect password, display an error message
            echo "Incorrect password";
        }
    } else {
        // User record not found, display an error message
        echo "Incorrect login information";
    }
}

// Close the connection
mysqli_close($conn);
?>
