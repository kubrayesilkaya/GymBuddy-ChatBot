<?php
        // Check if the form is submitted
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Retrieve the form data
            $email = $_POST["email"];
            $passsword = $_POST["passsword"];
            $age = $_POST["age"];
            $weight = $_POST["weight"];
            $height = $_POST["height"];

            // Perform the database update operation here
            // Replace the following code with your database update logic

            // Connect to the database
            $host = "localhost";
            $user = "root";
            $password = "";
            $dbname = "gymbuddy";
            $conn = mysqli_connect($host, $user, $password, $dbname);

            // Check connection
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }

            // Update the user's information in the database
            $sql = "UPDATE users SET password='$passsword', age='$age', weight='$weight', height='$height' WHERE email='$email'";
            if (mysqli_query($conn, $sql)) {
                echo "User information updated successfully";
            } else {
                echo "Error updating user information: " . mysqli_error($conn);
            }

            // Close the connection
            mysqli_close($conn);
            header("Location: http://localhost/finalGymBuddy/LogIn/Login.html");
            exit;
        }
    ?>