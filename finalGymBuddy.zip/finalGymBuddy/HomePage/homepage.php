<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>GymBuddy</title>
    <link href="Style.css" rel="stylesheet" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap" rel="stylesheet">
</head>

<body>
    
        <?php
            // Check if the name and surname are present in the URL query parameters
            if (isset($_GET['name']) && isset($_GET['surname'])) {
                // Retrieve the name and surname from the query parameters
                $name = $_GET['name'];
                $surname = $_GET['surname'];

                // Display the personalized message
                echo '<p class="personalizedMessage">Hello, ' . $name . ' ' . $surname . '!</p>';
            }
        ?>
    
    
    
    <div class="upper">
        <div class="aboutus">
            <a href="/finalGymBuddy/About_us/AboutUs.html" class="aboutusText">
                About us
            </a>
        </div>

        <div class="ExerciseTracking">
            <a href="/finalGymBuddy/Exersise Tracking/ExerciseTracking.html" class="ExerciseTrackingText">
                Exercise Tracking
            </a>
        </div>

        <div class="EditInfo">
            <a href="/finalGymBuddy/edit/html.html" class="EditInfoText">
                Edit Info
            </a>
        </div>

        <div class="logout">
            <a href="/finalGymBuddy/LogIn/Login.html" class="logoutText">
                Logout
            </a>
        </div>
    </div>

    <div class="middle">
        <div class="gym">
            <p class="gymText">
                Gym
            </p>
        </div>

        <div class="MidImg">
            <img class="ourImg" src="img/gym.png">
        </div>

        <div class="buddy">
            <p class="buddyText">
                Buddy
            </p>
        </div> 
    </div>

    <div class="chatbot">
        <input class="userinput" placeholder="Ask Your Question">
    </div>
</body>
</html>
